// sensor and lcd
OneWire ds(12);

LiquidCrystal lcd(2, 3, 4, 5, 6, 7);

// push buttons
const char Button_dn    = A5;
const char Button_up    = A4;
const char Button_enter = A3;
const char Button_start = A2;

// outputs
const byte Pump = 9;
const byte Buzz = 10;
const byte Heat = 11;


  
