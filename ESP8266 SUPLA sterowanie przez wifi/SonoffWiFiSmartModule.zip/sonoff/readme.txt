SUPLA FOR ITEAD SONOFF WiFi Smart Switch

sonoff_eagle.flash.bin-------->0x00000
sonoff_eagle.irom0text.bin---->0x40000

BAUDRATE: 115200
Flash Size: 1MByte
Flash speed: 40Mhz
SPI Mode: QIO

Youtube: https://www.youtube.com/watch?v=jO9yX2QVeoY

// ---------------------------------------------------
// ---------------------------------------------------
// ---------------------------------------------------

SUPLA FOR ITEAD SONOFF WiFi Smart Switch + DS18B20

sonoff_ds18b20_eagle.flash.bin-------->0x00000
sonoff_ds18b20_eagle.irom0text.bin---->0x40000

RX (GPIO3) - OneWire DAT


// CFG MODE ----------------------------------------

To bring the device into configuration
mode, press and hold button for at least 5 sec. When in configuration mode,
the device goes into Access Point mode.

In order to enter or change the settings, you need to:

- Sign in at https://cloud.supla.org (registration is free of charge)
- Connect to WiFi called „SUPLA-ESP8266” from any computer with a wireless network card and Internet browser.
- Open access page: http://192.168.4.1
- Enter user name and password to the WiFi through which the device will get Internet access.
- Enter Server address, Location ID and Location Password, which will be provided once you sign in at cloud.supla.org
